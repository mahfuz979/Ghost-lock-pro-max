package com.ghostlock.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Switch
import android.widget.TextView

private data class AppItem(val pkg: String, val label: String)

class AppsActivity : Activity() {

    private val all = ArrayList<AppItem>()
    private val shown = ArrayList<AppItem>()
    private val selected = HashSet<String>()
    private lateinit var adapter: AppAdapter
    private lateinit var countView: TextView
    private lateinit var emptyView: TextView

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(LocaleHelper.wrap(base))
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Colors.BG
        window.navigationBarColor = Colors.BG

        selected.addAll(Prefs.protectedApps(this))

        val launcherIntent = Intent(Intent.ACTION_MAIN)
        launcherIntent.addCategory(Intent.CATEGORY_LAUNCHER)
        val pm = packageManager
        val found = pm.queryIntentActivities(launcherIntent, 0)
        val list = found
            .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedWith(compareBy<AppItem>({ !selected.contains(it.pkg) }, { it.label.lowercase() }))
        all.addAll(list)
        shown.addAll(list)

        val root = FrameLayout(this)
        root.addView(AuroraView(this), FrameLayout.LayoutParams(MATCH, MATCH))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        val head = LinearLayout(this)
        head.orientation = LinearLayout.VERTICAL
        head.setPadding(dp(20), dp(20), dp(20), dp(8))
        head.addView(tv(getString(R.string.apps_title), 26f, Colors.TEXT, true))
        head.addView(tv(getString(R.string.apps_sub), 13f, Colors.MUTED))
        countView = tv("", 12f, Colors.ACCENT2, true)
        countView.setPadding(0, dp(8), 0, dp(10))
        head.addView(countView)

        val search = EditText(this)
        search.hint = getString(R.string.apps_search_hint)
        search.setHintTextColor(Colors.MUTED)
        search.setTextColor(Colors.TEXT)
        search.textSize = 15f
        search.setSingleLine(true)
        search.background = roundRect(withAlpha(Colors.TEXT, 20), 16, Colors.STROKE, 1)
        search.setPadding(dp(16), dp(12), dp(16), dp(12))
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                applyFilter(s?.toString() ?: "")
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        head.addView(search, LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))

        emptyView = tv(getString(R.string.apps_none), 14f, Colors.MUTED)
        emptyView.gravity = Gravity.CENTER
        emptyView.setPadding(dp(20), dp(24), dp(20), dp(8))
        emptyView.visibility = View.GONE
        col.addView(emptyView, LinearLayout.LayoutParams(MATCH, WRAP))

        val lv = ListView(this)
        adapter = AppAdapter()
        lv.adapter = adapter
        lv.divider = null
        lv.dividerHeight = dp(8)
        lv.clipToPadding = false
        lv.setPadding(dp(16), dp(8), dp(16), dp(24))
        lv.selector = ColorDrawable(Color.TRANSPARENT)
        lv.overScrollMode = View.OVER_SCROLL_NEVER
        lv.setOnItemClickListener { _, view, position, _ ->
            val pkg = shown[position].pkg
            if (selected.contains(pkg)) selected.remove(pkg) else selected.add(pkg)
            Prefs.setProtectedApps(this, selected)
            updateCount()
            adapter.notifyDataSetChanged()
            view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(70L).withEndAction {
                view.animate().scaleX(1f).scaleY(1f).setDuration(120L).start()
            }.start()
        }
        col.addView(lv, LinearLayout.LayoutParams(MATCH, 0, 1f))

        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)
        updateCount()
        listOf<View>(head).animateIn(0L)
    }

    private fun updateCount() {
        countView.text = getString(R.string.apps_selected, selected.size)
    }

    private fun applyFilter(query: String) {
        val q = query.trim().lowercase()
        shown.clear()
        for (a in all) {
            if (q.isEmpty() || a.label.lowercase().contains(q)) shown.add(a)
        }
        adapter.notifyDataSetChanged()
        emptyView.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
    }

    override fun onResume() {
        super.onResume()
        if (!Gate.ok(this)) finish()
    }

    override fun onPause() {
        super.onPause()
        Prefs.settingsUnlockedUntil = System.currentTimeMillis() + 60_000L
    }

    private inner class AppAdapter : BaseAdapter() {
        override fun getCount(): Int = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int): Long = position.toLong()

        private fun buildRow(): LinearLayout {
            val row = LinearLayout(this@AppsActivity)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(12), dp(10), dp(12), dp(10))

            val icon = ImageView(this@AppsActivity)
            icon.clipRound(dp(12).toFloat())
            row.addView(icon, LinearLayout.LayoutParams(dp(44), dp(44)))

            val name = tv("", 15f, Colors.TEXT)
            name.maxLines = 1
            val nlp = LinearLayout.LayoutParams(0, WRAP, 1f)
            nlp.marginStart = dp(12)
            row.addView(name, nlp)

            val sw = Switch(this@AppsActivity)
            sw.isClickable = false
            sw.isFocusable = false
            val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
            sw.thumbTintList = ColorStateList(states, intArrayOf(Colors.ACCENT2, Colors.MUTED))
            sw.trackTintList = ColorStateList(
                states,
                intArrayOf(withAlpha(Colors.ACCENT2, 110), withAlpha(Colors.MUTED, 80))
            )
            row.addView(sw)
            return row
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? LinearLayout) ?: buildRow()
            val icon = row.getChildAt(0) as ImageView
            val name = row.getChildAt(1) as TextView
            val sw = row.getChildAt(2) as Switch
            val item = shown[position]
            val sel = selected.contains(item.pkg)
            name.text = item.label
            sw.isChecked = sel
            row.background = roundRect(
                Colors.CARD, 16,
                if (sel) withAlpha(Colors.ACCENT2, 180) else Colors.STROKE, 1
            )
            try {
                icon.setImageDrawable(packageManager.getApplicationIcon(item.pkg))
            } catch (e: Exception) {
                icon.setImageDrawable(null)
            }
            return row
        }
    }
}
