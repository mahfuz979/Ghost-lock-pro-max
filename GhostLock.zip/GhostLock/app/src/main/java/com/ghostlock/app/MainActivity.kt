package com.ghostlock.app

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private companion object {
        const val REQ_PICK = 1001
    }

    private var picking = false
    private var pulse: ObjectAnimator? = null

    private lateinit var bannerCard: LinearLayout
    private lateinit var bannerTitle: TextView
    private lateinit var bannerSub: TextView
    private lateinit var bannerDot: View
    private lateinit var chipPhoto: TextView
    private lateinit var chipSecret: TextView
    private lateinit var chipApps: TextView
    private lateinit var chipService: TextView
    private lateinit var thumb: ImageView
    private lateinit var langPill: TextView

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(LocaleHelper.wrap(base))
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Colors.BG
        window.navigationBarColor = Colors.BG

        val root = FrameLayout(this)
        root.addView(AuroraView(this), FrameLayout.LayoutParams(MATCH, MATCH))

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(20), dp(20), dp(20), dp(28))

        // ---- header
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.addView(LockIconView(this), LinearLayout.LayoutParams(dp(76), dp(76)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.addView(tv(getString(R.string.app_name), 30f, Colors.TEXT, true))
        titles.addView(tv(getString(R.string.tagline), 13f, Colors.MUTED))
        val tlp = LinearLayout.LayoutParams(0, WRAP, 1f)
        tlp.marginStart = dp(8)
        header.addView(titles, tlp)
        langPill = tv("", 13f, Colors.TEXT, true)
        langPill.setPadding(dp(12), dp(8), dp(12), dp(8))
        langPill.background = roundRect(withAlpha(Colors.TEXT, 28), 20, Colors.STROKE, 1)
        langPill.pressable { showLanguageDialog() }
        header.addView(langPill)
        content.addView(header)

        // ---- status banner
        bannerCard = LinearLayout(this)
        bannerCard.orientation = LinearLayout.HORIZONTAL
        bannerCard.gravity = Gravity.CENTER_VERTICAL
        bannerCard.setPadding(dp(16), dp(16), dp(16), dp(16))
        val dotHolder = FrameLayout(this)
        bannerDot = View(this)
        dotHolder.addView(bannerDot, FrameLayout.LayoutParams(dp(14), dp(14), Gravity.CENTER))
        bannerCard.addView(dotHolder, LinearLayout.LayoutParams(dp(28), dp(28)))
        val bt = LinearLayout(this)
        bt.orientation = LinearLayout.VERTICAL
        bannerTitle = tv("", 17f, Colors.TEXT, true)
        bannerSub = tv("", 13f, Colors.MUTED)
        bt.addView(bannerTitle)
        bt.addView(bannerSub)
        val blp = LinearLayout.LayoutParams(0, WRAP, 1f)
        blp.marginStart = dp(8)
        bannerCard.addView(bt, blp)
        addBlock(content, bannerCard, 18)

        // ---- status rows
        val statusCard = LinearLayout(this)
        statusCard.orientation = LinearLayout.VERTICAL
        statusCard.setPadding(dp(16), dp(10), dp(16), dp(10))
        statusCard.background = roundRect(Colors.CARD, 18, Colors.STROKE, 1)
        chipPhoto = addStatusRow(statusCard, getString(R.string.row_photo))
        chipSecret = addStatusRow(statusCard, getString(R.string.row_secret))
        chipApps = addStatusRow(statusCard, getString(R.string.row_apps))
        chipService = addStatusRow(statusCard, getString(R.string.row_service))
        addBlock(content, statusCard, 12)

        // ---- steps
        val s1 = stepCard(1, getString(R.string.step1_title), getString(R.string.step1_sub), true) { pickPhoto() }
        val s2 = stepCard(2, getString(R.string.step2_title), getString(R.string.step2_sub), false) {
            if (Prefs.hasPhoto(this)) {
                startActivity(Intent(this, SecretAreaActivity::class.java))
            } else {
                toast(getString(R.string.toast_pick_photo_first))
            }
        }
        val s3 = stepCard(3, getString(R.string.step3_title), getString(R.string.step3_sub), false) {
            startActivity(Intent(this, AppsActivity::class.java))
        }
        val s4 = stepCard(4, getString(R.string.step4_title), getString(R.string.step4_sub), false) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addBlock(content, s1, 18)
        addBlock(content, s2, 10)
        addBlock(content, s3, 10)
        addBlock(content, s4, 10)

        // ---- notes
        val notes = LinearLayout(this)
        notes.orientation = LinearLayout.VERTICAL
        notes.setPadding(dp(4), dp(4), dp(4), 0)
        notes.addView(tv("🔒  " + getString(R.string.privacy_note), 12.5f, Colors.MUTED))
        val lt = tv(getString(R.string.limits_title), 12.5f, Colors.TEXT, true)
        lt.setPadding(0, dp(14), 0, dp(4))
        notes.addView(lt)
        notes.addView(tv(getString(R.string.limits_body), 12f, Colors.MUTED))
        addBlock(content, notes, 18)

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(content, ViewGroup.LayoutParams(MATCH, WRAP))
        root.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)

        listOf<View>(header, bannerCard, statusCard, s1, s2, s3, s4, notes).animateIn(80L)
    }

    private fun addBlock(parent: LinearLayout, v: View, topDp: Int) {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(topDp)
        parent.addView(v, lp)
    }

    private fun addStatusRow(card: LinearLayout, text: String): TextView {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(7), 0, dp(7))
        val name = tv(text, 14f, Colors.TEXT)
        row.addView(name, LinearLayout.LayoutParams(0, WRAP, 1f))
        val chip = tv("", 12f, Colors.TEXT, true)
        chip.setPadding(dp(10), dp(4), dp(10), dp(4))
        row.addView(chip)
        card.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        return chip
    }

    private fun stepCard(
        num: Int,
        title: String,
        sub: String,
        withThumb: Boolean,
        onClick: () -> Unit
    ): LinearLayout {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(dp(14), dp(14), dp(14), dp(14))
        card.background = roundRect(Colors.CARD, 18, Colors.STROKE, 1)

        val badge = tv(num.toString(), 16f, Colors.TEXT, true)
        badge.gravity = Gravity.CENTER
        badge.background = gradientOval(Colors.ACCENT, Colors.ACCENT2)
        card.addView(badge, LinearLayout.LayoutParams(dp(38), dp(38)))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(title, 16f, Colors.TEXT, true))
        col.addView(tv(sub, 12.5f, Colors.MUTED))
        val clp = LinearLayout.LayoutParams(0, WRAP, 1f)
        clp.marginStart = dp(12)
        card.addView(col, clp)

        if (withThumb) {
            thumb = ImageView(this)
            thumb.scaleType = ImageView.ScaleType.CENTER_CROP
            thumb.clipRound(dp(12).toFloat())
            thumb.visibility = View.GONE
            val tlp = LinearLayout.LayoutParams(dp(46), dp(46))
            tlp.marginStart = dp(8)
            card.addView(thumb, tlp)
        }

        val rtl = resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL
        val chev = tv(if (rtl) "‹" else "›", 26f, Colors.MUTED)
        val chlp = LinearLayout.LayoutParams(WRAP, WRAP)
        chlp.marginStart = dp(8)
        card.addView(chev, chlp)

        card.pressable(onClick)
        return card
    }

    private fun showLanguageDialog() {
        val langs = LocaleHelper.languages
        val names = (listOf(getString(R.string.lang_system)) + langs.map { it.name }).toTypedArray()
        val cur = Prefs.langOf(this)
        val checked = if (cur == "system") 0 else (langs.indexOfFirst { it.code == cur } + 1)
        AlertDialog.Builder(this)
            .setTitle(R.string.lang_dialog_title)
            .setSingleChoiceItems(names, checked) { d, which ->
                val code = if (which == 0) "system" else langs[which - 1].code
                Prefs.setLang(this, code)
                d.dismiss()
                recreate()
            }
            .show()
    }

    private fun pickPhoto() {
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.type = "image/*"
        i.addCategory(Intent.CATEGORY_OPENABLE)
        picking = true
        Prefs.settingsUnlockedUntil = System.currentTimeMillis() + 5 * 60 * 1000L
        try {
            @Suppress("DEPRECATION")
            startActivityForResult(Intent.createChooser(i, getString(R.string.chooser_title)), REQ_PICK)
        } catch (e: Exception) {
            picking = false
            toast(getString(R.string.toast_no_picker))
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        picking = false
        Prefs.settingsUnlockedUntil = System.currentTimeMillis() + 3 * 60 * 1000L
        if (requestCode != REQ_PICK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val appCtx = applicationContext
        Thread {
            val ok = Prefs.importPhoto(appCtx, uri)
            runOnUiThread {
                if (ok) {
                    toast(getString(R.string.toast_photo_saved))
                    startActivity(Intent(this, SecretAreaActivity::class.java))
                } else {
                    toast(getString(R.string.toast_photo_failed))
                }
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        if (!Gate.ok(this)) {
            finish()
            return
        }
        refresh()
    }

    override fun onPause() {
        super.onPause()
        if (!picking) {
            Prefs.settingsUnlockedUntil = System.currentTimeMillis() + 60_000L
        }
    }

    override fun onDestroy() {
        pulse?.cancel()
        super.onDestroy()
    }

    private fun isServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val cn = ComponentName(this, GhostLockService::class.java)
        val full = cn.flattenToString()
        val short = cn.flattenToShortString()
        return enabled.split(':').any { it.equals(full, true) || it.equals(short, true) }
    }

    private fun setChip(chip: TextView, text: String, color: Int) {
        chip.text = text
        chip.setTextColor(color)
        chip.background = roundRect(withAlpha(color, 50), 12)
    }

    private fun refresh() {
        val hasPhoto = Prefs.hasPhoto(this)
        val hasSecret = Prefs.hasSecret(this)
        val n = Prefs.protectedApps(this).size
        val svc = isServiceEnabled()

        setChip(
            chipPhoto,
            getString(if (hasPhoto) R.string.chip_ready else R.string.chip_missing),
            if (hasPhoto) Colors.GOOD else Colors.BAD
        )
        setChip(
            chipSecret,
            getString(if (hasSecret) R.string.chip_ready else R.string.chip_missing),
            if (hasSecret) Colors.GOOD else Colors.BAD
        )
        if (n > 0) {
            setChip(chipApps, getString(R.string.apps_selected, n), Colors.GOOD)
        } else {
            setChip(chipApps, getString(R.string.chip_none), Colors.WARN)
        }
        setChip(
            chipService,
            getString(if (svc) R.string.chip_on else R.string.chip_off),
            if (svc) Colors.GOOD else Colors.BAD
        )

        val active = hasPhoto && hasSecret && n > 0 && svc
        val c = if (active) Colors.GOOD else Colors.WARN
        bannerTitle.text = getString(if (active) R.string.status_active else R.string.status_setup)
        bannerSub.text = getString(if (active) R.string.status_active_sub else R.string.status_setup_sub)
        bannerCard.background = roundRect(withAlpha(c, 28), 18, withAlpha(c, 150), 1)
        bannerDot.background = ovalBg(c)

        pulse?.cancel()
        bannerDot.scaleX = 1f
        bannerDot.scaleY = 1f
        bannerDot.alpha = 1f
        val anim = ObjectAnimator.ofPropertyValuesHolder(
            bannerDot,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.5f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.5f),
            PropertyValuesHolder.ofFloat(View.ALPHA, 1f, 0.4f)
        )
        anim.duration = 900L
        anim.repeatCount = ValueAnimator.INFINITE
        anim.repeatMode = ValueAnimator.REVERSE
        anim.start()
        pulse = anim

        if (hasPhoto) {
            val b = Prefs.loadThumb(this, 160)
            if (b != null) {
                thumb.setImageBitmap(b)
                thumb.visibility = View.VISIBLE
            }
        } else {
            thumb.visibility = View.GONE
        }

        val code = resources.configuration.locales[0].language
        val shown = if (LocaleHelper.languages.any { it.code == code }) code else "en"
        langPill.text = "🌐 " + shown.uppercase()
    }
}
