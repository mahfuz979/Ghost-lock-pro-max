package com.ghostlock.app

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

object LocaleHelper {
    data class Lang(val code: String, val name: String)

    val languages = listOf(
        Lang("en", "English"),
        Lang("bn", "বাংলা"),
        Lang("hi", "हिन्दी"),
        Lang("ar", "العربية"),
        Lang("es", "Español")
    )

    fun wrap(base: Context): Context {
        val code = Prefs.langOf(base)
        if (code == "system") return base
        val locale = Locale(code)
        Locale.setDefault(locale)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(locale)
        cfg.setLayoutDirection(locale)
        return base.createConfigurationContext(cfg)
    }
}
