package com.ghostlock.app

import android.app.Activity
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar

class SecretAreaActivity : Activity() {

    private lateinit var photoView: PhotoTapView
    private lateinit var bar: LinearLayout
    private var barOnTop = false
    private var radius = 0.08f

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(LocaleHelper.wrap(base))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        secureWindow()
        goImmersive()

        val bmp = Prefs.loadBitmap(this)
        if (bmp == null) {
            toast(getString(R.string.toast_no_photo))
            finish()
            return
        }

        val frame = FrameLayout(this)
        photoView = PhotoTapView(this)
        photoView.bitmap = bmp
        if (Prefs.hasSecret(this)) {
            photoView.markerX = Prefs.secretX(this)
            photoView.markerY = Prefs.secretY(this)
            radius = Prefs.secretR(this)
            photoView.showMarker = true
        }
        photoView.markerR = radius
        photoView.onTap = { x, y ->
            photoView.markerX = x
            photoView.markerY = y
            photoView.showMarker = true
            photoView.pulseAt()
            photoView.invalidate()
        }
        frame.addView(photoView, FrameLayout.LayoutParams(MATCH, MATCH))

        bar = LinearLayout(this)
        bar.orientation = LinearLayout.VERTICAL
        bar.setPadding(dp(16), dp(14), dp(16), dp(14))
        bar.background = roundRect(Color.argb(225, 11, 16, 32), 22, withAlpha(Colors.TEXT, 40), 1)

        bar.addView(tv(getString(R.string.secret_hint), 13.5f, Colors.TEXT))

        val seek = SeekBar(this)
        seek.max = 17
        seek.progress = ((radius * 100f).toInt() - 3).coerceIn(0, 17)
        seek.progressTintList = ColorStateList.valueOf(Colors.ACCENT2)
        seek.thumbTintList = ColorStateList.valueOf(Colors.ACCENT2)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                radius = (progress + 3) / 100f
                photoView.markerR = radius
                photoView.invalidate()
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        val slp = LinearLayout.LayoutParams(MATCH, WRAP)
        slp.topMargin = dp(8)
        bar.addView(seek, slp)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL

        val btnSave = pillButton(getString(R.string.secret_save), true)
        btnSave.pressable { saveSecret() }
        row.addView(btnSave, LinearLayout.LayoutParams(0, WRAP, 1.3f))

        val btnMove = pillButton(getString(R.string.secret_move), false)
        btnMove.pressable { toggleBar() }
        val mlp = LinearLayout.LayoutParams(0, WRAP, 1f)
        mlp.marginStart = dp(8)
        row.addView(btnMove, mlp)

        val btnCancel = pillButton(getString(R.string.secret_cancel), false)
        btnCancel.pressable { finish() }
        val clp = LinearLayout.LayoutParams(0, WRAP, 1f)
        clp.marginStart = dp(8)
        row.addView(btnCancel, clp)

        val rlp = LinearLayout.LayoutParams(MATCH, WRAP)
        rlp.topMargin = dp(10)
        bar.addView(row, rlp)

        val barLp = FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM)
        barLp.setMargins(dp(12), dp(12), dp(12), dp(28))
        frame.addView(bar, barLp)
        setContentView(frame)
    }

    private fun toggleBar() {
        barOnTop = !barOnTop
        val lp = bar.layoutParams as FrameLayout.LayoutParams
        lp.gravity = if (barOnTop) Gravity.TOP else Gravity.BOTTOM
        bar.layoutParams = lp
    }

    private fun saveSecret() {
        if (!photoView.showMarker) {
            toast(getString(R.string.toast_tap_first))
            return
        }
        Prefs.saveSecret(this, photoView.markerX, photoView.markerY, radius)
        Prefs.settingsUnlockedUntil = System.currentTimeMillis() + 3 * 60 * 1000L
        toast(getString(R.string.toast_secret_saved))
        finish()
    }

    override fun onResume() {
        super.onResume()
        if (!Gate.ok(this)) finish()
    }

    override fun onPause() {
        super.onPause()
        Prefs.settingsUnlockedUntil = System.currentTimeMillis() + 60_000L
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) goImmersive()
    }
}
