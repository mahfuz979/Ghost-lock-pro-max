package com.ghostlock.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min
import kotlin.math.sin

/** Animated app logo: a glowing lock whose shackle lifts up now and then. */
class LockIconView(context: Context) : View(context) {

    private var phase = 0f
    private var animator: ValueAnimator? = null
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val body = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shackle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.WHITE
    }
    private val hole = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0B1020") }
    private val path = Path()
    private val bodyRect = RectF()
    private val arcRect = RectF()

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 4000L
        a.repeatCount = ValueAnimator.INFINITE
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
        a.start()
        animator = a
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val s = min(w, h)
        if (s <= 0f) return
        val cx = w / 2f
        val cy = h / 2f

        val pulse = (sin(phase * 6.2831855f) + 1f) / 2f
        val gr = s * (0.42f + 0.08f * pulse)
        glow.shader = RadialGradient(
            cx, cy, gr,
            intArrayOf(Color.argb(150, 124, 108, 255), Color.TRANSPARENT),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, gr, glow)

        bodyRect.set(cx - s * 0.22f, cy - s * 0.02f, cx + s * 0.22f, cy + s * 0.28f)
        body.shader = LinearGradient(
            bodyRect.left, bodyRect.top, bodyRect.right, bodyRect.bottom,
            Colors.ACCENT, Colors.ACCENT2, Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(bodyRect, s * 0.06f, s * 0.06f, body)

        val lift = if (phase in 0.55f..0.75f) sin(((phase - 0.55f) / 0.2f) * 3.1415927f) else 0f
        val gap = lift * s * 0.07f
        val left = cx - s * 0.13f
        val right = cx + s * 0.13f
        val baseY = bodyRect.top - gap
        val topY = baseY - s * 0.20f
        arcRect.set(left, topY, right, topY + (right - left))
        shackle.strokeWidth = s * 0.06f
        path.reset()
        path.moveTo(left, baseY)
        path.lineTo(left, topY + (right - left) / 2f)
        path.arcTo(arcRect, 180f, 180f)
        path.lineTo(right, baseY)
        canvas.drawPath(path, shackle)

        canvas.drawCircle(cx, bodyRect.centerY() - s * 0.01f, s * 0.035f, hole)
        canvas.drawRect(cx - s * 0.012f, bodyRect.centerY(), cx + s * 0.012f, bodyRect.centerY() + s * 0.07f, hole)
    }
}
