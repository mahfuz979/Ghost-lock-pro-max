package com.ghostlock.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.TextView

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

object Colors {
    val BG = Color.parseColor("#0B1020")
    val CARD = Color.parseColor("#141A33")
    val STROKE = Color.parseColor("#252E57")
    val TEXT = Color.parseColor("#FFFFFF")
    val MUTED = Color.parseColor("#9AA4C7")
    val ACCENT = Color.parseColor("#7C6CFF")
    val ACCENT2 = Color.parseColor("#22D3EE")
    val GOOD = Color.parseColor("#2EE59D")
    val BAD = Color.parseColor("#FF6B81")
    val WARN = Color.parseColor("#FFB84D")
}

fun withAlpha(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha shl 24)

fun Context.roundRect(fill: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.shape = GradientDrawable.RECTANGLE
    g.cornerRadius = dp(radiusDp).toFloat()
    g.setColor(fill)
    if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor)
    return g
}

fun Context.gradientBg(c1: Int, c2: Int, radiusDp: Int): GradientDrawable {
    val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2))
    g.cornerRadius = dp(radiusDp).toFloat()
    return g
}

fun ovalBg(color: Int): GradientDrawable {
    val g = GradientDrawable()
    g.shape = GradientDrawable.OVAL
    g.setColor(color)
    return g
}

fun gradientOval(c1: Int, c2: Int): GradientDrawable {
    val g = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2))
    g.shape = GradientDrawable.OVAL
    return g
}

fun Context.tv(text: CharSequence, sizeSp: Float, color: Int, bold: Boolean = false): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = sizeSp
    t.setTextColor(color)
    if (bold) t.typeface = Typeface.DEFAULT_BOLD
    return t
}

fun Context.pillButton(text: String, filled: Boolean): TextView {
    val t = tv(text, 15f, Colors.TEXT, true)
    t.gravity = Gravity.CENTER
    t.setPadding(dp(12), dp(12), dp(12), dp(12))
    t.background = if (filled) gradientBg(Colors.ACCENT, Colors.ACCENT2, 14)
    else roundRect(withAlpha(Colors.TEXT, 40), 14)
    return t
}

@SuppressLint("ClickableViewAccessibility")
fun View.pressable(onClick: () -> Unit) {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
        }
        false
    }
    setOnClickListener { onClick() }
}

fun List<View>.animateIn(baseDelayMs: Long = 0L) {
    forEachIndexed { i, v ->
        v.alpha = 0f
        v.translationY = v.context.dp(24).toFloat()
        v.animate()
            .alpha(1f)
            .translationY(0f)
            .setStartDelay(baseDelayMs + i * 70L)
            .setDuration(450L)
            .setInterpolator(DecelerateInterpolator())
            .start()
    }
}

fun View.clipRound(radiusPx: Float) {
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
        }
    }
    clipToOutline = true
}
