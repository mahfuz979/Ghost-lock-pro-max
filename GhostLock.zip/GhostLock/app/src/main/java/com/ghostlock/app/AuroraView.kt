package com.ghostlock.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/** Slowly drifting glowing color blobs on a dark background. */
class AuroraView(context: Context) : View(context) {

    private var t = 0f
    private var animator: ValueAnimator? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val baseX = floatArrayOf(0.15f, 0.85f, 0.50f)
    private val baseY = floatArrayOf(0.10f, 0.38f, 0.95f)
    private val rad = floatArrayOf(0.60f, 0.55f, 0.65f)
    private val cols = intArrayOf(
        Color.argb(120, 124, 108, 255),
        Color.argb(90, 34, 211, 238),
        Color.argb(80, 255, 94, 216)
    )

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val a = ValueAnimator.ofFloat(0f, 6.2831855f)
        a.duration = 20000L
        a.repeatCount = ValueAnimator.INFINITE
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
        a.start()
        animator = a
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Colors.BG)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        for (i in 0 until 3) {
            val cx = w * (baseX[i] + 0.12f * sin(t + i * 2.1f))
            val cy = h * (baseY[i] + 0.08f * cos(t * 0.8f + i * 1.7f))
            val r = max(w, h) * rad[i]
            paint.shader = RadialGradient(
                cx, cy, r, intArrayOf(cols[i], Color.TRANSPARENT), null, Shader.TileMode.CLAMP
            )
            canvas.drawCircle(cx, cy, r, paint)
        }
    }
}
