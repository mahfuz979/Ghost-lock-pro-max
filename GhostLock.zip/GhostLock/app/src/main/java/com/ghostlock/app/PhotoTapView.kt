package com.ghostlock.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.max

/**
 * Draws a bitmap with "center crop" over the whole view and reports taps as
 * fractions (0..1) of the view width/height. Optionally draws a marker circle.
 */
class PhotoTapView(context: Context) : View(context) {

    var bitmap: Bitmap? = null
        set(value) {
            field = value
            invalidate()
        }

    var showMarker: Boolean = false
    var markerX: Float = 0.5f
    var markerY: Float = 0.5f
    var markerR: Float = 0.08f // fraction of view width

    var onTap: ((Float, Float) -> Unit)? = null

    private val src = Rect()
    private val dst = RectF()
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val ringDark = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 10f
        color = Color.BLACK
    }
    private val ringLight = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        color = Color.WHITE
    }
    private var pulse = 0f
    private var pulseAnim: ValueAnimator? = null
    private val pulsePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f
        color = Color.WHITE
    }

    /** Small ripple animation shown in setup when the secret spot is placed. */
    fun pulseAt() {
        pulseAnim?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 550L
        a.addUpdateListener {
            pulse = it.animatedValue as Float
            invalidate()
        }
        a.start()
        pulseAnim = a
    }

    override fun onDetachedFromWindow() {
        pulseAnim?.cancel()
        super.onDetachedFromWindow()
    }

    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)
        val b = bitmap ?: return
        val vw = width.toFloat()
        val vh = height.toFloat()
        if (vw <= 0f || vh <= 0f) return

        val scale = max(vw / b.width, vh / b.height)
        val srcW = vw / scale
        val srcH = vh / scale
        val left = (b.width - srcW) / 2f
        val top = (b.height - srcH) / 2f
        src.set(left.toInt(), top.toInt(), (left + srcW).toInt(), (top + srcH).toInt())
        dst.set(0f, 0f, vw, vh)
        canvas.drawBitmap(b, src, dst, bmpPaint)

        if (showMarker) {
            val cx = markerX * vw
            val cy = markerY * vh
            val r = markerR * vw
            canvas.drawCircle(cx, cy, r, ringDark)
            canvas.drawCircle(cx, cy, r, ringLight)
            canvas.drawCircle(cx, cy, 6f, dot)
            if (pulse > 0.001f && pulse < 0.999f) {
                pulsePaint.alpha = ((1f - pulse) * 200f).toInt()
                canvas.drawCircle(cx, cy, r * (1f + 0.7f * pulse), pulsePaint)
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> return true
            MotionEvent.ACTION_UP -> {
                if (width > 0 && height > 0) {
                    onTap?.invoke(event.x / width, event.y / height)
                }
                performClick()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        return super.performClick()
    }
}
